
export const NoPage = () => {
    return (
        <h1>From NoPage</h1>
    )
}