export const Admin = () => {
    return (
        <h1>Admin</h1>
    )
} 