import { Link } from "react-router-dom";
import logo from "./../../assets/logo192.png"
export const Header = () => {
    return (
        <header>
            <Link to="/" className="logo">
                <img src={logo} alt="" />
            </Link>
            <nav className="navigation">
                <Link to="/" className="logo">
                    Home
                </Link>
                <Link to="/login" className="logo">
                    Login
                </Link>
                <Link to="/registration" className="logo">
                    Registration
                </Link>
                <Link to="/count" className="logo">
                    Count
                </Link>
                <Link to="/task" className="logo">
                    TaskList
                </Link>
            </nav>
        </header>
    )
}