export const Home = () => {
    return (
        <h1>From Home</h1>
    )
}