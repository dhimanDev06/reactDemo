import { useState } from "react";
export const TaskList = () => {
    const [tasks,tasksState] = useState([
        {id:123, name:"Dhiman", show:true},
        {id:124, name:"Susmita", show:false},
        {id:125, name:"Suman", show:true},

        {id:111, name:"Baban", show:false}
    ])
    const deletTask = (indx)=>{
        console.log("deletTask",indx,);
        tasksState(tasks.filter((a)=>a.id!=indx))
    }
    // function deletTask(indx) {
    //     console.log("deletTask",indx);
    // }
    return (
        <div>
            <h1>TaskList</h1>   
            {/* <ul>
                { tasks.map((t)=> !t.show &&
                    <li key={t.id}>
                        <p>
                        {t.name}
                        </p>
                        <button onClick={()=>deletTask(t.id)}>Delete</button>
                    </li>
                )}
                
            </ul> */}
            <ul>
            {tasks.map((t)=>  t.show && <li key={t.id}>
                        <p>
                        {t.name}
                        </p>
                        <button onClick={()=>deletTask(t.id)}>Delete</button>
                    </li>)}
            </ul>
        </div>
        
    )
}