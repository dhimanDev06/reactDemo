export const Registration = () => {
    return (
        <h1>From Registration</h1>
    )
}